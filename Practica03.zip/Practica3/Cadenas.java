public class Cadenas implements Metodos{
    private String cadena;
    private int vocales=0;
    private String cadenaInvertida;
    
    //Metodo constructor
    //public Cadenas (String cadena){
      //  this.cadena = cadena;
    //}
    
    //Getters y setters
    public String getCadenas(){
        return this.cadena;
    }

    public void setCadenas(String cadena){
        this.cadena = cadena;
    }

    public int getVocales(){
        return this.vocales;
    }

     public String getCadenaInvertida(){
        return this.cadenaInvertida;
    }

    //Metodos de la interface Metodos
    @Override
    public int vocales(String cadena){
        for (int j=0; j<cadena.length(); j++){
            char verificar = cadena.charAt(j);
            switch(verificar){
                case 'a':
                vocales += 1;
                break;

                case 'e':
                vocales += 1;
                break;

                case 'i':
                vocales += 1;
                break;

                case 'o':
                vocales += 1;
                break;

                case 'u':
                vocales += 1;
                break;
                
                case 'A':
                vocales += 1;
                break;

                case 'E':
                vocales += 1;
                break;

                case 'I':
                vocales += 1;
                break;

                case 'O':
                vocales += 1;
                break;

                case 'U':
                vocales += 1;
                break;
                default:
            }
        }
        return vocales;
    }

    @Override
    public String reversa(String cadena) {
        for (int j = cadena.length(); j>=0; j--){
            this.cadenaInvertida = "" + cadena.charAt(j);
        }
        return cadenaInvertida;
    }

    @Override
    public int posicion(String cadena, char caracter) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'posicion'");
    }
    @Override
    public boolean esNatural(String cadena) {
        boolean bandera = false;
        for (int j=0; j<cadena.length(); j++){
            char verificar = cadena.charAt(j);
            switch(verificar){
                case '1':
                bandera = true;
                break;
                case '2':
                bandera = true;
                break;
                case '3':
                bandera = true;
                break;
                case '4':
                bandera = true;
                break;
                case '5':
                bandera = true;
                break;
                case '6':
                bandera = true;
                break;
                case '7':
                bandera = true;
                break;
                case '8':
                bandera = true;
                break;
                case '9':
                bandera = true;
                break;
                case '0':
                bandera = true;
                break;
                default:
                bandera = false;
            }
        }
        return bandera;
    }

    @Override
    public boolean esReal(String cadena) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'esReal'");
    }
    @Override
    public String cambiar(String cadena, char cambiar, char nuevo) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'cambiar'");
    }
    @Override
    public boolean palindromo(String cadena) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'palindromo'");
    }
    @Override
    public int cuentaCaracter(String cadena, char caracter) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'cuentaCaracter'");
    }
    @Override
    public String subCadena(String cadena, int inicio, int fin) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'subCadena'");
    }
    @Override
    public boolean esPrimo(int numero) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'esPrimo'");
    }
    @Override
    public int sumaDigitos(int numero) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'sumaDigitos'");
    }
    @Override
    public int cuentaPalabras(String cadena) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'cuentaPalabras'");
    }
}

//     public String toString(){
//         return "" + vocales;
//     }
// }
//         ",\tEdad: "+edad+
//         ",\tEnergia: "+energia+
//         ",\tVacunado: "+vacunado+
//         ",\tJuguete: "+juguete;
// }
