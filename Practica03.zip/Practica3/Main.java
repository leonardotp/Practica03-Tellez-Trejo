public class Main {
    public static void main(String[] args) {
        Cadenas primerCadena = new Cadenas();
        boolean res = primerCadena.esNatural("hola");
        boolean res2 = primerCadena.esNatural("13098");
        String res3 = primerCadena.reversa("12345");
        
        System.out.println(res);
        System.out.println(res2);
        System.out.println(res3);
    }
}
